package com.prog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CheckedExceptionMain {

	public static void main(String[] args ) throws IOException {
	int age;
	String name;
	float fees;
		
		InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);
	
		System.out.println("Enter name");
		
		name = br.readLine();
		System.out.println("Enter your age");
		age = Integer.parseInt(br.readLine());
		System.out.println("Enter your fees");
		fees = Float.parseFloat(br.readLine());
		
		
		System.out.println("Your name = "+name);
		System.out.println("Your age = "+age);
		System.out.println("Fees = "+fees);
		

	}

}
