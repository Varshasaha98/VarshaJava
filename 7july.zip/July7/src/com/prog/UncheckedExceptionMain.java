package com.prog;

public class UncheckedExceptionMain {

	public static void main(String[] args) {
		int a=12,b=0,c=0;
		System.out.println("Before division");
		c=a/b;
		System.out.println("After division");

	}

}
