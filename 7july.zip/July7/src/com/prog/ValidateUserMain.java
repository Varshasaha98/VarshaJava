package com.prog;

import java.util.Scanner;

class ValidateUser{
	String uname,pass;
	
	void validateData() {
		try {
			System.out.println("Enter the username");
		Scanner sc = new Scanner(System.in);
		
		uname=sc.nextLine();
		System.out.println("Enter the password");
		Scanner p = new Scanner(System.in);
		pass=p.nextLine();
	}catch(NumberFormatException | NullPointerException e) {
		e.printStackTrace();
	}
	}
	void checkData() {
		if(uname.equalsIgnoreCase("Admin") && pass.equals("admin123")) {
			System.out.println("Validating user input");
		}
		else {
			System.out.println("Invalid Input");
		}
	}
}




public class ValidateUserMain {

	public static void main(String[] args) {
		ValidateUser ob = new ValidateUser();
		ob.validateData();
		ob.checkData();
	}

}
