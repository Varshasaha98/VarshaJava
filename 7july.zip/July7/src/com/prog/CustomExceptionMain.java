package com.prog;

class AgeCheckException extends Exception{
	public AgeCheckException(String s) {
		super(s);
	}
}

class VoteAge{
	public void checkAgeVote(int age) {
		if(age<18) {
			try {
			AgeCheckException erob=new AgeCheckException("Not eligible for voting");
			throw erob;
			}catch(AgeCheckException e){
				e.printStackTrace();
			}
		}
			else {
				System.out.println("Eligible for Vote");
			}
	}
}

public class CustomExceptionMain {

	public static void main(String[] args) {
		VoteAge vob = new VoteAge();
		vob.checkAgeVote(2);

	}

}
