package com.prog;

class Employee{
	int eid;
	String name;
	float salary;
	public Employee(int eid, String name, float salary) {
		
		this.eid = eid;
		this.name = name;
		this.salary = salary;
	}
	
	void display() {
		System.out.println("Eid= "+eid);
		System.out.println("Name = "+name);
		System.out.println("Salary = "+salary);
	}
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid=eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary=salary;
	}
}

public class EmployeeMain {

	public static void main(String[] args) {
		Employee e1 = new Employee(10,"kiran",8976.76f);
		Employee e2 = new Employee(11,"Atul",8974.76f);
		Employee e3 = new Employee(10,"Divyansh",89.76f);
		
		e1.display();
		e2.display();
		e3.display();
		
		//setter and getter method
		Employee eobsetget = new Employee();
		eobsetegt.setEid;
	}

}
