package com.prog;

class A{
	A(){
		System.out.println("class A constructor");
	}
}
class B extends A{
	B(){
		System.out.println("class B constructor");
	}
}
class C extends B{
	public C() {
		
	}
}

public class ConstructMainInh {

	public static void main(String[] args) {
		

	}

}
