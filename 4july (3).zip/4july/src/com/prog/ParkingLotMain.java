package com.prog;

import java.util.Scanner;

class ParkingLot{
	int vno;
	int hours;
	double amount;
	
	void input() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your vehicle number");
		vno=sc.nextInt();
		System.out.println("Enter your hours");
		hours=sc.nextInt();
	}
	void calculate() {
		amount=3+(1.5*(hours-1));
		
	}
	void display() {
		System.out.println("Your Vehicle number is : "+vno);
		System.out.println("Hours you need to park your vehicle : "+hours);
		System.out.println("Your payable amount is : "+amount);
	}
}

public class ParkingLotMain {
 static void main(String[] args) {
		ParkingLot obp = new ParkingLot();
		obp.input();
		obp.calculate();
		obp.display();
		

	}

}
