package com.prog;

import java.util.Scanner;

class Student{
	int sid;
	String sname;
	float sfees;
	public Student() {
		
	}
	public void input() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name");
		sname=sc.nextLine();
		System.out.println("enter fees");
		sfees=sc.nextFloat();
		System.out.println("enter id");
		sid=sc.nextInt();
	}
	public void display() {
		System.out.println("Id: "+sid);
		System.out.println("Name: "+sname);
		System.out.println("Fees: "+sfees);
	}
}


public class ArrayObjectStudent {

	public static void main(String[] args) {
		Student sob[] = new Student[5];
		
		for(int i=0; i<sob.length;i++) {
			sob[i]=new Student();
		}
		for(int i=0;i<sob.length;i++) {
			sob[i].input();
			
		}
		System.out.println("All Student Records");
		for(int i=0;i<sob.length;i++) {
			sob[i].display();
		}

	}

}
