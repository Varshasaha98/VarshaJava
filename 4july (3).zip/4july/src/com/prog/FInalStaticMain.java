package com.prog;
class Employee1{// if class is final you cannot have a child class
	
    /*int i=10;//final is constant at variables ,cannot change the value
	
	void inputData() {//if the method is final you cannot override it in subclass
		i=i+1;
	}*/
	int name;
	static String companyname;
	static {//use for static data initialization
		companyname="Edubridge India";//static can acess only static data
		
		System.out.println("static1");
	}
	static {
		System.out.println("static2");
	}
	
	
	public static void staticMethod() {
		System.out.println("Static method employee"+companyname);
	}
	public void nonstaticmethod() {
		System.out.println("name="+name);
		System.out.println("static:"+companyname);
	}
}
class Accountant extends Employee1{
	/*void inputData() {
		
	}*/
	public static void staticMethod() {
		//super.staticMethod();//inside static method cannot be used
		//static methods cannot be overriden
		System.out.println("Static method Accountant");
	}
}

public class FInalStaticMain {

	public static void main(String[] args) {
	Accountant aob = new Accountant();	
	aob.staticMethod();
	Employee1.staticMethod();//static method can be called reffer to class and object name

	}

}
