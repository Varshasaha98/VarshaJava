package com.prog;

public class DifferentBlockJavaMain {
	
	static {
		System.out.println("Static block will exectute before the main method");
		}
	{
		System.out.println("Anonymous block will exectute before constructor block");
	}
	DifferentBlockJavaMain(){
		System.out.println("This is constructor block");
	}

	public static void main(String[] args) {
		System.out.println("this is main block");
		DifferentBlockJavaMain ob = new DifferentBlockJavaMain();
	}

}
