package com.prog;

import java.util.Scanner;

class Railway{
	String cname;
	String coach;
	long mobno;
	int amnt;
	int totalamnt;
	Scanner sc= new Scanner(System.in);
	void accept() {
		System.out.println("Enter your name");
		cname=sc.nextLine();
		System.out.println("Enter the coach type you want");
		coach=sc.nextLine();
		System.out.println("Enter your mobile number here:");
		mobno=sc.nextLong();
		System.out.println("Enter the amount of ticket");
		amnt=sc.nextInt();
		
	}
	
	void update() {
		if(coach.equalsIgnoreCase("First_Ac")) {
			totalamnt=amnt+700;
			
		}
		else if(coach.equalsIgnoreCase("Second_Ac")) {
			totalamnt=amnt+500;
			
		}
		else if(coach.equalsIgnoreCase("Third_Ac")) {
			totalamnt=amnt+250;
			
		}
		else if(coach.equalsIgnoreCase("Sleeper")){
			totalamnt=amnt;
			
		}
		else {
			System.out.println("Invalid Case");
		}
		//System.out.println("Your total amount is :"+totalamnt);
	}
	void display() {
		System.out.println("name : "+cname);
		System.out.println("Coach name : "+coach);
		System.out.println("Mobile number : "+mobno);
		System.out.println("amount : "+amnt);
		System.out.println("total amount"+totalamnt);
	}
	
}

public class RailwayTicketMain {

	public static void main(String[] args) {
		Railway obr = new Railway();
		obr.accept();
		obr.update();
		obr.display();

	}

}
