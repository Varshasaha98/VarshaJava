package com.prog;

import java.util.Scanner;

class ShowRoom{
	String name;
	long mno;
	double cost;
	double disc;
	double amount;
	
	ShowRoom(){
		name=null;
		mno=0;
		cost=0.0;
		disc=0.0;
		amount=0.0;
		
	}
	void input() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name : ");
		name=sc.nextLine();
		System.out.println("Enter your mobile number : ");
		mno=sc.nextLong();
		System.out.println("Enter the cost : ");
		cost=sc.nextDouble();
	}
	void calculate() {
		if(cost<=10000) {
			disc=(cost*5)/100;
			
		}
		else if(cost>10000 && cost<=20000) {
			disc=(cost*10)/100;
			
		}
		else if(cost>20000 && cost<=35000) {
			disc=(cost*15)/100;
		}
		else if(cost>35000) {
			disc=(cost*20)/100;
		}
	}
	void display() {
		System.out.println("Name : "+name);
		System.out.println("Mobile number : "+mno);
		System.out.println("Your total amount is "+(cost-disc));
	}
}
public class ShowRoomMain {

	public static void main(String[] args) {
		ShowRoom obs=new ShowRoom();
		obs.input();
		obs.calculate();
		obs.display();

	}

}
