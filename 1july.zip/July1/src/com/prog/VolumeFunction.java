package com.prog;

class VolumeFinding{
	
	void volume(double r) {
		
		double v=(4/3)*(22/7)*(r*r*r);
		System.out.println("volume of sphere is = "+v);
	}
	void volume(double h, double r){
		double v=(22/7)*(r*r)*h;
		System.out.println("volume of cylinder is = "+v);
	}
	void volume(double l,double b,double h) {
		double v=l*b*h;
		System.out.println("Volume of cuboid is = "+v);
		
	}
}
public class VolumeFunction {

	public static void main(String[] args) {
		VolumeFinding ob = new VolumeFinding();
		ob.volume((double)4.3);
		ob.volume((double)4,(double) 8);
		ob.volume((double)2,(double) 10,(double)12);

	}

}
