package com.prog;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeeTestCase {

	@Test
	public void checkStr() {
		String name="edubridge";
		assertEquals(name, "edubridge");
	}
	public void add() {
		int s;
		int a,b;
		a=20;
		b=49;
		s=a+b;
		assertEquals(s,69);
	}

}
