package com.edu;

import java.util.Scanner;

public class Vowels {

	public static void main(String[] args) {
		
		char letter;
		String vowel;
		Scanner sc = new Scanner(System.in);
		System.out.println("enetr a single alphabet in lower case");
		letter= sc.next().charAt(0);
		vowel=(letter=='a'|| letter=='e'|| letter=='i'|| letter=='o'|| letter=='u'|| letter=='A'|| letter=='E' || letter=='I' || letter=='O'
				|| letter=='U')?"A Vowel" : "A CONSONANT";
		System.out.println("Letter "+letter+" is "+vowel);
		
	}

}
