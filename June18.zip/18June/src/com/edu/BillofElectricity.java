package com.edu;

import java.util.Scanner;

public class BillofElectricity {

	public static void main(String[] args) {
		
		int units;
		String name;
		float billamount;
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter Your name here:");
		name = sc.nextLine();
		System.out.println("Please enter your units here:");
		units = sc.nextInt();
		if (units<=0) {
			System.out.println("Invalid Input");
			System.exit(0);
		}
		else {
		
		if(units>=1 && units<=100) {
			billamount = units*2.0f;
		}
		
		else if(units>=101 && units<=300) {
			billamount= units*2.0f+(units-100)*3.0f;
		}
		
		else {
			billamount = units*2.0f+(units-100)*3.0f+(units-300)*5.0f;
			billamount = billamount+(0.025f)*billamount;
		}
		
	
		System.out.println("Customer name: "+name);
		System.out.println("Units consumed: "+units);
		System.out.println("Your total billamount is: "+billamount);
	}

}
}
