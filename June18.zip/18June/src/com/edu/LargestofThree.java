package com.edu;

import java.util.Scanner;

public class LargestofThree {

	public static void main(String[] args) {
		
		int first, second, third;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 3 numbers");
		
		

	}

}
