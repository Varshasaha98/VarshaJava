package com.edu;

import java.util.Scanner;

public class MarksRange {

	public static void main(String[] args) {
		
		char grade; 
		Scanner sc = new Scanner(System.in);
		
		 System.out.println("Enter you Grade here: ");
		 
		 grade = sc.next().charAt(0);
		 
		 if(grade=='A') {
			 System.out.println("your marks range is 80-100");
		 }
		 else if(grade=='B') {
			 System.out.println("your marks range is 60-79");
		 }
		 else if(grade=='C') {
			 System.out.println("your marks range is 0-59");
		 }
		 else {
			 System.out.println("invalid");
		 }

	}

}
