package com.edu;

import java.util.Scanner;

public class ElseIfLadder {

	public static void main(String[] args) {
		 
		int marks;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the marks");
		 marks = sc. nextInt();
		 if(marks<=100 && marks>=80) {
			 System.out.println("Your grade is A ");
			
		 }
		 else if(marks<=79 && marks>=60) {
			 System.out.println("Your grade is B");
		 }
		 
		 else if(marks<=59 && marks>=35) {
			 System.out.println("Your grade is C"); 
		 }
		 else if(marks<=0 && marks>=34) {
			 System.out.println("You are Fail");
		 }
		 else if(marks>100 && marks<0) {
			 System.out.println("Invalid Input");
			 
		 }

	}

}
