package com.prog;

import java.util.Scanner;

public class ArrayDemoMain {

	public static void main(String[] args) {
		int ar[];
		int size;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of an array:");
		size=sc.nextInt();
		ar = new int[size];
		System.out.println("Enter "+ar.length+"of elements");
		
		for(int i=0;i<ar.length;i++) {
			ar[i]=sc.nextInt();
		}
		for(int i:ar) {
			System.out.println(i);
		}

	}

}
