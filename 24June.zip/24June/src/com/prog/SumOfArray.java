package com.prog;

import java.util.Scanner;

public class SumOfArray {

	public static void main(String[] args) {
		
		int size,i,sum=0,ar[];
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the size of Array:");
		size=sc.nextInt();
		ar=new int[size];
		for(i=0;i<size;i++) {
			System.out.println("enter the number:");
			ar[i]=sc.nextInt();
			}
		for(i=0;i<size;i++) {
		sum=sum+ar[i];
		}
		System.out.println("sum= "+sum);

	}

}
