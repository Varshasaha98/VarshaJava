package com.prog;

import java.util.Scanner;

class ArrayOperator{
	int min,max,sum,size,i,ar[];
	float average;
	
	public void InputData() {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the size of array");
		size = sc.nextInt();
		ar=new int[size];
		
		for(i=0;i<size;i++) {
		System.out.println("enter the elements:");
		ar[i]=sc.nextInt();

		
		}
	}
	
	public void sumArray() {
	
		for(i=0;i<size;i++) {
		sum=sum+ar[i];
		}
		

	}
	public void averageArray() {
		for(i=0;i<size;i++) {
			sum=sum+ar[i];
			}
		
		float average=(float)sum/size;
		System.out.println("The average of Array elemts is: "+average);
	}
	
	public void largestArray() {
		max = ar[0];
		for(i=1;i<size;i++) {
	if(ar[i]>max) {
		max = ar[i];
		
	}
		}
	}
		public void leastArray() {
			min = ar[0];
			for(i=1;i<size;i++) {
				if(ar[i]<min) {
					min = ar[i];
		}
			}
	
	}
			
			public void displayData() {
				System.out.println("sum= "+sum);
				
				System.out.println("largest of array elements "+max);
				System.out.println("least of Array elements: "+min);
			}
		
		
		}


public class LargestInArray {

	public static void main(String[] args) {
		ArrayOperator obj = new ArrayOperator();
		
		obj.InputData();
		obj.sumArray();
		obj.averageArray();
		obj.largestArray();
		obj.leastArray();
		obj.displayData();
		
	
	
	}
	}





