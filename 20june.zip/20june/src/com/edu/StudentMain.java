package com.edu;

import java.util.Scanner;

class Student{
	int sid;
	String sname;
	float sfees;
	
	void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name:");
		sname=sc.nextLine();
		System.out.println("Enter Id:");
		sid=sc.nextInt();
		System.out.println("Enter Your fees");
		sfees=sc.nextFloat();
		
	}
	
	void displayData() {
		
		System.out.println("Name= "+sname);
		System.out.println("Student Id = "+sid);
		System.out.println("Student fees = "+sfees);
	}
}

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student sobj = new Student();
		Student sobj1=new Student();
		sobj.inputData();
		sobj.displayData();
		
		sobj1.inputData();
		sobj1.displayData();
		
		System.out.println("sobj ref "+sobj);
		System.out.println("name= "+sobj.sname+" Id "+sobj.sid+" fees "+sobj.sfees);
		System.out.println("sobj1 ref "+sobj1);


	}

}
