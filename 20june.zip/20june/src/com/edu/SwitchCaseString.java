package com.edu;

import java.util.Scanner;

public class SwitchCaseString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String day;
		System.out.println("Enter name of the day");
		day = sc.nextLine();
		switch(day) {
		case "Monday":System.out.println("the number of day is 1");
		break;
		case "Tuesday": System.out.println("The number of day is 2");
		break;
		case "Wednesday": System.out.println("The number of day is 3");
		break;
		case "Thursday": System.out.println("The number of day is 4");
		break;
		case "Friday": System.out.println("The number of day is 5");
		break;
		case "Saturday": System.out.println("The number of day is 6");
		break;
		case "Sunday": System.out.println("The number of day is 7");
		break;
		default: System.out.println("Invalid");
		}
	

	}

}
