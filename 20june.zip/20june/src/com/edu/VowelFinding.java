package com.edu;

import java.util.Scanner;


public class VowelFinding {

	public static void main(String[] args) {
		char vowelL;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your letter here:");
		vowelL = sc.next().charAt(0);
		switch(vowelL) {
		case 'A': System.out.println("letter is vowel");
		break;
		case 'E': System.out.println("letter is vowel");
		break;
		case 'I': System.out.println("letter is vowel");
		break;
		case 'O': System.out.println("letter is vowel");
		break;
		case 'U': System.out.println("letter is vowel");
		break;
		default: System.out.println("letter is consonant");
		
		}
		
	}

}
