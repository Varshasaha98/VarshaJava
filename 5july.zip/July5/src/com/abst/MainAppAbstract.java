package com.abst;

abstract class Myabstractclass{
	void display() {
		System.out.println("Display method");
	}
	
}

public class MainAppAbstract extends Myabstractclass{

	public static void main(String[] args) {
		MainAppAbstract ob = new MainAppAbstract();
		ob.display();

	}

}
