package com.prog;

class MyClass{
	final void finalMethod() {
		System.out.println("Final method cannot be overriden");
		}
	static void staticMethod() {
		System.out.println("Parent class static Method");
	}
	void normalMethod() {
		System.out.println("Normal Method");
	}
}

public class ChildClass extends MyClass {
	
	static void staticMethod() {
		System.out.println("Child static method executed ");
	}
	void normalMethod() {
		super.normalMethod();
		System.out.println("Child class normal method");
	}

	public static void main(String[] args) {
		ChildClass ob = new ChildClass();
		ob.finalMethod();

	}

}
