package package1;

public class OtherClassAcess {
	private int privateval;
	public int publicval;
	protected int protectedval;
	int defaultval;
	
	public OtherClassAcess() {
		privateval=20;
		publicval=17;
		protectedval=30;
		defaultval=50;
		
	}
	public void method1() {
		System.out.println("n= "+privateval);
	}

}
