package package1;

import package2.Package2Class;

public class AcessSpecifierMain extends Package2Class {

	
	
	public static void main(String[] args) {
		
		OtherClassAcess obj = new OtherClassAcess();
		System.out.println("default data "+obj.defaultval);
		System.out.println("public data "+obj.publicval);
		System.out.println("protected data "+obj.protectedval);
		
		
		//for packages
		//AcessSpecifierMain mob = new AcessSpecifierMain();
		//System.out.println(mob.publicp2val);
		//System.out.println(mob.protectedp2val);
		Package2Class pob = new Package2Class();
		System.out.println(pob.publicp2val);

	}

}
