package package2;

public class Package2Class {
	private int privatep2val;
	public int publicp2val;
	protected int protectedp2val;
	int defp2val;
	
	public Package2Class() {
		privatep2val=10;
		publicp2val=18;
		protectedp2val=20;
		defp2val=30;
	}

}
