package com.prog;

import java.util.Scanner;

class ArrayLinearSearch{
	int arr[],size,key;
	
	public void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of an Array");
		size=sc.nextInt();
		arr = new int[size];
		System.out.println("Enter the "+size+"Array elements");
		System.out.println("Enter Array elements: ");
		for(int i=0;i<size;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the keky element to search:");
		key=sc.nextInt();
	}
	public void displayElements() {
		System.out.println("Array elements are ");
		for(int i=0;i<size;i++) {
			System.out.println(arr[i]);
		}
	}
	 public void linearSearch() {
		 int pos=-1;
		 for(int i=0;i<size;i++) {
			 if(key==arr[i]) {
				 pos=i;//pos=1
				 break;
			 }
		 }
		 if(pos>=0) {
			 System.out.println("Successful search");
			 System.out.println("The key element "+key+"is at "+(pos+1));
		 }
		 else {
			 System.out.println("Unsuccessful search, Element not found.");
		 }
		 
	 }
}

public class MainAppArray {

	public static void main(String[] args) {
		ArrayLinearSearch aa = new ArrayLinearSearch();
		aa.inputData();
		aa.displayElements();
		aa.linearSearch();
		
	}

}
