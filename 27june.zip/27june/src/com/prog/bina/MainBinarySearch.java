package com.prog.bina;
import java.util.Scanner;

class BinarySearch {
	int arr[],size,key;
	
	void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size of an Array:");
		size=sc.nextInt();
		arr=new int[size];
		System.out.println("Enter "+size+" array elements:");
		for(int i=0;i<size;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the key element to search");
		key = sc.nextInt();
	}
	
	public void searchBinary() {
		int l,h,mid=0, pos=-1;
		l=0;
		h=size-1;
		while(l<=h) {
			mid=(l+h)/2;
			if(key==arr[mid]) {
				pos=mid;
				break;
			}
			else if(key>=arr[mid]) {
				l=mid+1;
			}
			else if(key<=arr[mid]) {
				h=mid-1;
			}
		}
		if(pos>=0) {
			System.out.println(key+" found at "+(mid+1));
		}
		else {
			System.out.println(key+" is not found.");
		}
	}
}

public class MainBinarySearch {

	public static void main(String[] args) {
		BinarySearch ab = new BinarySearch();
		ab.inputData();
		ab.searchBinary();
	}

}
