package com.prog.emp.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prog.emp.entity.Department;
import com.prog.emp.error.DepartmentNotFoundException;
import com.prog.emp.error.EmployeeNotFoundException;
import com.prog.emp.repository.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Override
	public Department addDepartment(@Valid Department department) {
		// TODO Auto-generated method stub
		return departmentRepository.save(department);
	}

	@Override
	public void deleteDepartment(Integer depid) throws DepartmentNotFoundException{
		Optional<Department> department= departmentRepository.findById(depid);
		if(!department.isPresent()) {
			throw new DepartmentNotFoundException("Department id Not Exists");
		}else {
			departmentRepository.deleteById(depid);;
		}
		
	}


	@Override
	public Department updateDepartment(Integer departmentId, Department department) throws DepartmentNotFoundException {
		 Optional<Department> department1 = departmentRepository.findById(departmentId);
			
			if(!department1.isPresent())
				throw new DepartmentNotFoundException("Department Id not available");
			
			else {
				Department deptDB = departmentRepository.findById(departmentId).get();
			
			if(deptDB.getDepartmentName()!=null)
				deptDB.setDepartmentName(department.getDepartmentName());
			return departmentRepository.save(deptDB);
		}
		
	}

	
}
