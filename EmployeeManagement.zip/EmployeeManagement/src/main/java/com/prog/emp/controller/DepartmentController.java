package com.prog.emp.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.prog.emp.entity.Department;
import com.prog.emp.error.DepartmentNotFoundException;
import com.prog.emp.service.DepartmentService;

@RestController
public class DepartmentController {

	@Autowired
	private DepartmentService departmentService;
	
	@PostMapping("/department")
	public ResponseEntity<Department> addDepartment(@Valid @RequestBody Department department){
		Department deptobj = departmentService.addDepartment(department);
		return new ResponseEntity<Department>(deptobj,HttpStatus.CREATED);
	}
	
	@DeleteMapping("/deletedepartment/{depid}")
	public String deleteDepartment(@PathVariable ("depid") Integer depid) throws DepartmentNotFoundException {
		departmentService.deleteDepartment(depid);
		return "Depsrtment Deleted";
	}
	
	@PutMapping("/updatedepartment/{deptid}")
	public Department updateDepartment(@PathVariable ("deptid") Integer departmentId,@RequestBody Department department) throws DepartmentNotFoundException{
		return departmentService.updateDepartment(departmentId,department);
	}
	
}
