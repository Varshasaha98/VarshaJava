package com.prog.emp.service;

import javax.validation.Valid;

import com.prog.emp.entity.Employee;
import com.prog.emp.error.EmployeeNotFoundException;

public interface EmployeeService {

	

	void deleteEmployee(Integer empid) throws EmployeeNotFoundException;

	Employee addEmployee(Employee employee);

}
