package com.prog.emp.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Integer employeeId;
	@NotEmpty
	@Size(min=3,max=40,message = "Name should be min 3 and max 30 chars")
	private String employeeName;
	@Min(18)
	private int employeeAge;
	@Email(message="enter a valid email")
	private String employeeEmail;
	@Min(value=10000, message = "Salary should not be less than 10000")
	@Max(value=1000000, message = "Salary should not be more than 1000000")
	private float employeeSalary;
	
	
	//Many to one
	
	public float getEmployeeSalary() {
		return employeeSalary;
	}


	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}


	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "department_Id", referencedColumnName = "departmentId")
	Department department;
	
	
	public Integer getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public Department getDepartment() {
		return department;
	}


	public void setDepartment(Department department) {
		this.department = department;
	}


	public int getEmployeeAge() {
		return employeeAge;
	}


	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}


	public String getEmployeeEmail() {
		return employeeEmail;
	}


	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}


	

	
}
