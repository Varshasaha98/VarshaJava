package com.prog.emp.service;



import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prog.emp.entity.Employee;
import com.prog.emp.error.EmployeeNotFoundException;
import com.prog.emp.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public void deleteEmployee(Integer empid) throws EmployeeNotFoundException {
		Optional<Employee> employee=employeeRepository.findById(empid);
		
		if(!employee.isPresent()) {
			throw new EmployeeNotFoundException("Employee id Not Exists");
		}else {
			employeeRepository.deleteById(empid);;
		}
		
	}

	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(employee);
	}

}
