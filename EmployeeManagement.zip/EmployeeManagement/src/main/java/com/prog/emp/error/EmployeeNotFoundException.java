package com.prog.emp.error;

public class EmployeeNotFoundException extends Exception{

	public EmployeeNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
	

}
