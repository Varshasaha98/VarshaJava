package com.prog.emp.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.prog.emp.entity.Employee;
import com.prog.emp.error.EmployeeNotFoundException;
import com.prog.emp.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/addemployee")
	public ResponseEntity<Employee> addEmployee(@Valid @RequestBody Employee employee) {
		Employee empobj = employeeService. addEmployee(employee);
		return new ResponseEntity<Employee>(empobj, HttpStatus.CREATED);
		
	}
	
	@DeleteMapping("/deleteemployee/{empid}")
	public String deleteEmployee(@PathVariable("empid") Integer empid) throws EmployeeNotFoundException {
		 employeeService.deleteEmployee(empid);
		 return "Employee Deleted";
	}
	
}
