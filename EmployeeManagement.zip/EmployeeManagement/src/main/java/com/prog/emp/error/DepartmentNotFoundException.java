package com.prog.emp.error;

public class DepartmentNotFoundException extends Exception{
	
	public DepartmentNotFoundException (String message) {
	
		super(message);
	}

}
