package com.prog.emp.service;

import javax.validation.Valid;

import com.prog.emp.entity.Department;
import com.prog.emp.error.DepartmentNotFoundException;

public interface DepartmentService {

	Department addDepartment(@Valid Department department);

	void deleteDepartment(Integer depid) throws DepartmentNotFoundException;

	

	Department updateDepartment(Integer departmentId, Department department) throws DepartmentNotFoundException;

}
