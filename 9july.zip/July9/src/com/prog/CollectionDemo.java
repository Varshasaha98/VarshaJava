package com.prog;

import java.util.ArrayList;
public class CollectionDemo {

	public static void main(String[] args) {
		int a[]=new int[5];
		//limitation: similar data type
		//fixed size, cannot go beyond5, fixed memory
		
		//dynamic storage
		
		/*ArrayList alob =new ArrayList();
		alob.add(4);
		alob.add(9.8f);
		alob.add(9.8);
		alob.add("still");*/
		
		//Dynamic Array
		
		ArrayList<Integer> lob = new ArrayList();
		lob.add(24);
		lob.add(76);
		lob.add(87);
		lob.add(98);
		
		
		System.out.println(lob);
		
		//for each
		for(int i:lob) {
			System.out.println(i);
		}
		
		ArrayList<Float> fob = new ArrayList();
		fob.add(78.6f);
		

	}

}
