package com.prog.str;

public class Addition {
	
	int a,b,s;
	
	Addition(){
	a=10;
	b=56;
	System.out.println("constructor is called");
	System.out.println("");
	}
	Addition(int i, int j){
		System.out.println("Constructor with argumrnt is called");
		a=i;
		b=j;
		
	}
	void add() {
		s=a+b;
		System.out.println("s= "+s);
		
	}
	
	
public static void main(String[] args) {
	Addition ob = new Addition();
	ob.add();
	Addition ob1 = new Addition();
	
	ob1.add();
	Addition ob2 = new Addition(6,9);
	ob2.add();
	Addition ob3 = new Addition(6,10);
	
	ob3.add();
	


}
}
