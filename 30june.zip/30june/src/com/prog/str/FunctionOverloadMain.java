package com.prog.str;

class Overload{
	
	void addition(int i,int j) {
	int a=i;
	int b=j;
	int sum;	
	sum=a+b;
		System.out.println("integer sum = "+sum);
	}
	void addition(float i,float j) {
		float sum;
		float a=i;
		float b=i;
		sum = a+b;
		System.out.println("Float sum = "+sum);
	}
	void addition(double i, double j) {
		double a=i,b=j,sum;
		sum=a+b;
		System.out.println("Double sum = "+sum);
		
	}
	void addition(byte i,byte j) {
		byte a=i,b=j;
		int sum;
		sum=a + b;
		System.out.println("Byte sum = "+sum);
		
	}
	void addition(short i, short j) {
		short a=i,b=j;
		int sum;
		sum=a+b;
		System.out.println("Short sum = "+sum);
	}
}

public class FunctionOverloadMain {

	public static void main(String[] args) {
		Overload a = new Overload();
		a.addition(20,40);
		a.addition(2.3f,3.5f);
		a.addition(45.9,32.1);
		a.addition((byte)87,(byte) 45);
		a.addition((short)23,(short)43);
	}

}
