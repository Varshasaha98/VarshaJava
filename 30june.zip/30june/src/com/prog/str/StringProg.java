package com.prog.str;

public class StringProg {

	public static void main(String[] args) {
		
		String s="Vital Infromation Resource Under Seize";
		 String word ="" + s.charAt(0);
		
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i);
			if(ch==' ') {
				word+=s.charAt(i+1);
			}
			
		}
		System.out.println(word);

	}

}
