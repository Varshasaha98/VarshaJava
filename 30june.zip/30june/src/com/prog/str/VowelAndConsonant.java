package com.prog.str;


class Alphabet{
	
	
	
	public int uniqueVowel(String str) {
	
		
		char [] c=str.toLowerCase().toCharArray();
		int counter=0;
		String NewString="";
		for(int i=0;i<c.length;i++) {
			String tempString="";
			tempString+=c[i];
			if(!NewString.contains(tempString)&&(c[i]=='a'||c[i]=='i'||c[i]=='e'||c[i]=='o'||c[i]=='u')) {
				counter++;
				
				NewString+=c[i];
			}
		}
       
           
		
		
		return counter;
		
		
	}
	
	public int uniqueConsonant(String str) {
		
		
		char [] c=str.toLowerCase().toCharArray();
		int counter=0;
		String NewString="";
		for(int i=0;i<c.length;i++) {
			String tempString="";
			tempString+=c[i];
			if(!NewString.contains(tempString)&&(c[i]=='a'||c[i]=='i'||c[i]=='e'||c[i]=='o'||c[i]=='u')) {
				System.out.println("");
				
				
			}else {
				counter++;
				NewString+=c[i];
			}
		}
       
		
		return counter;
	}
	
	
}
public class VowelAndConsonant {
	
	public static void main(String[] args) {
		Alphabet obj = new Alphabet();
		System.out.println(obj.uniqueVowel("abacab"));
		 System.out.println(obj.uniqueConsonant("acabbba"));
		
	}

}
