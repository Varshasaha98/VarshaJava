package com.prog;

class MyOuterClass{
	int i;
	static int j;
	static class InnerStatic{
		//static inner class method can access only static data of outer class
		//even though its not a static it will become by default static as it is inside a static
		void innerFunction() {
			System.out.println("Static class Method"+j);		}
	}
}

public class StaticInnerClassMain {

	public static void main(String[] args) {
		MyOuterClass.InnerStatic ob = new MyOuterClass.InnerStatic();
		ob.innerFunction();

	}

}
