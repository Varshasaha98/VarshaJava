package com.prog;

class OuterClassLocal{
	void outerMethodLocal() {
		class LocalInnerClass{
			void localInnerMethod() {
				System.out.println("Local Inner Method");
				
			}
		}
		 LocalInnerClass linob = new  LocalInnerClass();
		 linob.localInnerMethod();
	}
}

public class LocalInnerMain {

	public static void main(String[] args) {
		OuterClassLocal obj = new OuterClassLocal();
		obj.outerMethodLocal();
		
	}

}
