package com.prog;

class OuterClass{
	int i,j;
	public OuterClass() {
		i=10;
		j=55;
	}
	class InnerClass{
		void innerMethod() {
			System.out.println("sum= "+(i+j));	}
	}
	void outerMethod() {
		System.out.println("Outer method");
		InnerClass inob = new InnerClass();
		inob.innerMethod();
	}
}

public class MainInnerApp {

	public static void main(String[] args) {
		OuterClass outob= new OuterClass();
		outob.outerMethod();

	}

}
