package com.prog;

abstract class Product{
	abstract public void display();
}
interface MyInterface{
	void intmethod();
	void intmethod1();
}

public class AnonymousInnerMain {

	public static void main(String[] args) {
		
		/*new Product(){
		@Override
		public void display(){
	      }
		}.display*/
		
		//Shortcut for anonymous class
		
		
		
		Product pob = new Product() {

			@Override
			public void display() {
				
				System.out.println("product Method");
			}
			
			
		};
		pob.display();
		
		MyInterface iob = new MyInterface() {

			@Override
			public void intmethod() {
				
				System.out.println("Interface Method");
			}

			@Override
			public void intmethod1() {
				
				
			}
			
		};
		iob.intmethod();

	}

}
