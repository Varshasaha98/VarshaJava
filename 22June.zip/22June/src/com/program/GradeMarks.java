package com.program;

import java.util.Scanner;

public class GradeMarks {

	public static void main(String[] args) {
		int range;
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter you Range here");
		range= sc.nextInt();
		if(range>=80 && range<=100) {
			System.out.println("Your Grade is: A");
		}
		
		else if(range>=60 && range<=79) {
			System.out.println("Your Grade is: B");
		}
		else if(range>=59 && range<=35) {
			System.out.println("Your Grade is: C");
		}
		else if(range>=0 && range<=34){
			System.out.println("Fail");
		}
		else {
			System.out.println("Invalid Input");
		}
	}
}