package com.prog.pcm.service;

import java.util.List;

import com.prog.pcm.entity.Product;

public interface ProductService {

	Product addProduct(Product product);

	List<Product> getProductDetail();

}
