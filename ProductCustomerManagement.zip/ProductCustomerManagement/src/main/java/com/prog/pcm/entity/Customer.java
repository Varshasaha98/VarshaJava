package com.prog.pcm.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Customer {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer customerId;
	private String customerName;
	private String customerPhone;
	
	//relation
	@ManyToMany
	@JoinTable(name="product_detail",joinColumns= @JoinColumn (name="customer_Id"), inverseJoinColumns = @JoinColumn(name="product_Id") )
	Set<Product>productdetail=new HashSet<>();
	
	
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public Set<Product> getProductdetail() {
		return productdetail;
	}
	public void setProductdetail(Set<Product> productdetail) {
		this.productdetail = productdetail;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	public void productdetail(Product product) {
		productdetail.add(product);
		
	}
	
	
	
}
