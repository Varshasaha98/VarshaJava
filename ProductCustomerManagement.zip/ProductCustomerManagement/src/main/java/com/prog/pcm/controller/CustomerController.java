package com.prog.pcm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.prog.pcm.entity.Customer;
import com.prog.pcm.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@PostMapping("/addcustomer")
	public Customer addCustomer(@RequestBody Customer customer) {
		return customerService.addCustomer(customer);
		
	}
	
	@GetMapping("/getcustomer")
	public List<Customer> getCustomerDetails() {
		return customerService.getCustomerDetails();
		
	}
	
	@PutMapping("/customer/{cusid}/product/{prodid}")
	public Customer productDetailToCustomer(@PathVariable ("cusid") Integer cusid,@PathVariable ("prodid") Integer prodid) {
		return customerService.productDetailToCustomer(cusid,prodid);
		
	}
	
}
