package com.prog.pcm.service;

import java.util.List;

import com.prog.pcm.entity.Customer;

public interface CustomerService {

	Customer addCustomer(Customer customer);

	List<Customer> getCustomerDetails();

	Customer productDetailToCustomer(Integer cusid, Integer prodid);

}
