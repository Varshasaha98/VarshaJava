package com.prog.pcm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prog.pcm.entity.Customer;
import com.prog.pcm.entity.Product;
import com.prog.pcm.repository.CustomerRepository;
import com.prog.pcm.repository.ProductRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private ProductRepository productRepository;
	
	@Override
	public Customer addCustomer(Customer customer) {
		
		return customerRepository.save(customer);
	}

	@Override
	public List<Customer> getCustomerDetails() {
		
		return customerRepository.findAll();
	}

	@Override
	public Customer productDetailToCustomer(Integer cusid, Integer prodid) {
		Customer customer = customerRepository.findById(cusid).get();
		Product product = productRepository.findById(prodid).get();
		customer.productdetail(product);
		return customerRepository.save(customer);
	}
	
	
	

}
