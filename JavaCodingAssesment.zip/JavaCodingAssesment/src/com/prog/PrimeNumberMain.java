package com.prog;

import java.util.Scanner;
class Prime{
	int c;
	public void generatePrime() {
		for(int i=1;i<=100;i++) {
			int c=0;
			for(int j=1;j<=i;j++) {
				if(i%j==0) {
					c++;
					
				}
			}
			if(c==2) {
				System.out.println(i+" ");
			}
		}
	}
}
public class PrimeNumberMain {

	public static void main(String[] args) {
		Prime pob= new Prime();
		pob.generatePrime();

	}

}
