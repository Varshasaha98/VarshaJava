package com.prog;

import java.util.Scanner;

public class PrimeOrNotMain {

	public static void main(String[] args) {
		int num,count=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number ");
		num=sc.nextInt();
		for(int i=1;i<=num;i++) {
			if(num%i==0) {
				count++;
			}
			
			
		}
		if(count>2) {
			System.out.println("The number "+num+" is not prime");
		}
		else {
			System.out.println("the number "+num+" is prime");
		}

	}

}
