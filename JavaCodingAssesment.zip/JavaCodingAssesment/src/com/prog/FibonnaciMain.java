package com.prog;

import java.util.Scanner;

public class FibonnaciMain {
	

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int num,first,second,third;
		first=0;
		second=1;
		third=1;
		System.out.println("Enter the terms");
		num=sc.nextInt();
		System.out.println("series is");
		for(int i=1;i<=num;i++) {
			
			first=second;
			second=third;
			third=first+second;
			
			System.out.print(first+" ");
		}
		
	
	}

	}


