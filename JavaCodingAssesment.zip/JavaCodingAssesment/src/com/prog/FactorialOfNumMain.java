package com.prog;

import java.util.Scanner;

public class FactorialOfNumMain {

	public static void main(String[] args) {
		double fact=1;
		int num,i;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number ");
		num=sc.nextInt();
		for( i=1;i<=num;i++) {
			fact=fact*i;
		}
		System.out.println("Factorial of th number "+num+" is "+fact);

	}

}
