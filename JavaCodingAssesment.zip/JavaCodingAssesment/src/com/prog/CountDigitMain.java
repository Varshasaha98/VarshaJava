package com.prog;

import java.util.Scanner;

class Digitcount{
	int count=0;
	int num;
	int rev;
	Digitcount(){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter the number you want to reverse ");
		num=sc.nextInt();
	}
	
	
	
	public void count() {
		int temp=num;
		while(num!=0) {
			int dig=num%10;
			rev=rev*10+dig;
			num=num/10;
			//count++;
			
		}
		//System.out.println("Number of digits in the digit are ="+count);
		System.out.println(rev);
	
	}
	
	void palindrome() {
		int temp=num;;
		if(temp==rev) {
			System.out.println("Number is palindrome");
		}else {
			System.out.println("Number is not Palindrome");
		}
		
	}
		
}
public class CountDigitMain {

	public static void main(String[] args) {
		
		Digitcount dob = new Digitcount();
		
		dob.count();
		dob.palindrome();
	}

}
