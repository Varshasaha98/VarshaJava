package com.prog;

import java.util.Scanner;

class TwoNumber{
	int first,second;
	public void inputData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		first=sc.nextInt();
		System.out.println("enter second number to compare");
		second = sc.nextInt();
		
	}
	
	public void findLargest() {
		/*if(first>second) {
			System.out.println("largest of "+first+" and "+second+" is "+first);
		}else {
			System.out.println("largest of "+first+" and "+second+" is "+second);
		}
	}*/
		
		int largest=(first>second)?first:second;
		System.out.println("largest of "+first+" and "+second+" is "+largest);
}}

public class LargestOfTwoNum {

	public static void main(String[] args) {
		TwoNumber obj =new  TwoNumber();
		obj.inputData();
		obj.findLargest();

	}

}
