package com.prog.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JDBCOperations {

	private static Connection myconn;
	private static ResultSet rs;
	private static Statement st;
	public static void displayStudents() throws SQLException {
		myconn=DatabaseConnection.getConnection();
		
		st=myconn.createStatement();
		String sel="Select * from student";
		rs = st.executeQuery(sel);
		
		System.out.println(rs);
		System.out.println("sid\tsname\tdob\tcourse\tfees");
		
		while(rs.next()) {
			int sn = rs.getInt(1);
			String sname = rs.getString(2);
			int cid = rs.getInt(3);
			String dob=rs.getString(4);
			float fs=rs.getFloat(5);
			
			System.out.println(sn+"\t"+sname+"\t"+dob+"\t"+cid+"\t"+fs);
			
		}
	}
	public static void addStudents() throws SQLException {
		myconn=DatabaseConnection.getConnection();
		st=myconn.createStatement();
		
		int sid,cid;
		String sn;
		float sfees;
		String dob;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter student name");
		sn=sc.next();
		System.out.println("Enter student Id");
		sid=sc.nextInt();
		System.out.println("Enter student dob");
		dob=sc.next();
		System.out.println("Enter the student course");
		cid=sc.nextInt();
		System.out.println("Enter the fees:");
		sfees=sc.nextFloat();
		
		
		try {
			
			
			String sel="Select * from student where sid="+sid;
			rs=st.executeQuery(sel);
			if(rs.next()) {
				System.out.println(sid+"already exist");
			}else {
				
	
			
			String ins="insert into student values("+sid+",'"+sn+"','"+cid+"','"+dob+"',"+sfees+")";
			System.out.println(ins);
			int rval=st.executeUpdate(ins);
			if(rval>0) {
				System.out.println("Record is added");
			}else {
				System.out.println("Record not added");
			}
			

	}}catch(Exception e)
		{
		e.printStackTrace();
	}
	
	}
	
	public static void deleteStudent() throws SQLException {
		
		myconn=DatabaseConnection.getConnection();
		st=myconn.createStatement();
		int stid;
		Scanner sc = new Scanner(System.in);
		try {
			
			System.out.println("Enter sid to delete record");
			stid=sc.nextInt();
			String sel = "Select * from student where sid="+stid;
			rs=st.executeQuery(sel);
			if(rs.next()) {
				String del="delete from student where sid ="+stid;
				int retval=st.executeUpdate(del);
				if(retval>0) {
					System.out.println("Record is deleted");
				}else {
					System.out.println("Error! occured");
				}
				
			}else {
				System.out.println(stid+"id doesn't exist");
			}
			
		}catch(Exception e) {
		
			e.printStackTrace();
		}

		
	}
	
	public static void updateStudent() throws SQLException {
		
		myconn=DatabaseConnection.getConnection();
		st=myconn.createStatement();
		
	
			
		int stid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Select the option to update record:");
		System.out.println("1. Update Name.");
		System.out.println("2. Update Date of Birth.");
		
		int update;
		update=sc.nextInt();
		switch(update) {
		
		case 1:
			try {
				
				
				System.out.println("Enter the sid to update");
				stid=sc.nextInt();
				
				System.out.println("Enter the name");
				String sname=sc.next();
				
				String sel="Select * from student where sid = "+stid;
				rs=st.executeQuery(sel);
				
				if(rs.next()) {
					String upd="update student set sname ='"+sname+"' where sid ="+stid;
					int retval=st.executeUpdate(upd);
					if(retval>0) {
						System.out.println("Student name changed");
						
					}else {
						System.out.println("Error!!!");
					}
					
				}else {
					System.out.println(stid+"not exists for updating record");
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			break;
			
		case 2:
			try {
			System.out.println("Enter the sid ");
			stid=sc.nextInt();
			System.out.println("Enter the Date of birth to update");
			String dob=sc.next();
			String sel="Select * from student where sid = "+stid;
			rs=st.executeQuery(sel);
			
			if(rs.next()) {
				String upd="update student set dob ='"+dob+"' where sid ="+stid;
				int retval=st.executeUpdate(upd);
				if(retval>0) {
					System.out.println("Student Date of Birth changed");
					
				}else {
					System.out.println("Error!!!");
				}
				
			}else {
				System.out.println(dob+"does not exists for updating record");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
			
			break;
		default:
			System.out.println("Invalid Input");
			break;
		}
		
	
}
}
