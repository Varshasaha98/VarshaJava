package com.prog.jdbc;

import java.sql.SQLException;
import java.util.Scanner;

public class MainJdbcOperations {

	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
		
		int choice;
		char ch;
		while(true) {
		System.out.println("*************MENU****************");
		System.out.println("Database Operations");
		System.out.println("Enter your choice");
		System.out.println("1. Display Students");
		System.out.println("2. Add the new record");
		System.out.println("3. Delete the record");
		System.out.println("4. Update the record");
		
		
		choice= sc.nextInt();
		switch(choice) {
		case 1://display
			System.out.println("Display the Records of students");
			JDBCOperations.displayStudents();
			break;
		case 2: //add student
			System.out.println("Add a new student in records");
			JDBCOperations.addStudents();
			break;
		case 3: //delete based on id
			System.out.println("Delete Record of student");
			JDBCOperations.deleteStudent();
			break;
		case 4: //update
			System.out.println("Update Student Record");
			JDBCOperations.updateStudent();
			break;
			default:
				break;
		}
		System.out.println("Do you want to continue y/n");
		ch=sc.next().charAt(0);
		if(ch=='n'|| ch=='N') 
			break;
		}
		System.out.println("Your program is terminated.");
	}

}
