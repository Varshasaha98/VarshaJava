package com.prog;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RetriveRecordPrepared {

	public static void main(String[] args) {
		
		
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/shonadatabase";
		String un="root";
		String up="root";
		Connection conn=null;
		PreparedStatement pst;
		ResultSet rs=null;
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			String selsql="select * from student";
			pst=conn.prepareStatement(selsql);
			rs=pst.executeQuery();
			System.out.println("sid\tsname\tcid\tdob\t\tsfees");
			while(rs.next()) {
				int id=rs.getInt("sid");
				String sn=rs.getString("sname");
				int cd=rs.getInt("cid");
				String dob=rs.getString("dob");
				float fees=rs.getFloat("sfees");
				
				System.out.println(id+"\t"+sn+"\t"+cd+"\t"+dob+"\t"+fees);
					
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}
