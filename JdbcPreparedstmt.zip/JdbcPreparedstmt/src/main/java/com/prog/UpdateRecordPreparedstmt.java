package com.prog;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateRecordPreparedstmt {

	public static void main(String[] args) throws SQLException {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/shonadatabase";
		String un="root";
		String up="root";
		Connection conn=null;
		PreparedStatement pst;
		ResultSet rs=null;
		int stid;
		String sn;
		
		Scanner sc= new Scanner(System.in);
		 try {
				Class.forName(driver);
				conn=DriverManager.getConnection(url,un,up);
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		 
		 System.out.println("Enter student id to update record");
			stid=sc.nextInt();
			String sel="Select * from student where sid=?";
			pst=conn.prepareStatement(sel);
			
			
			
			pst.setInt(1,stid);
			rs=pst.executeQuery();
		 System.out.println(rs);
			if(rs.next()) {
				System.out.println("Select the option from below you want to update");
				System.out.println("1. Update the student name.");
				System.out.println("2. Update the fees");
				int input;
			 input=sc.nextInt();
		 
		 switch(input) {
		 case 1: 
			
				
					System.out.println("Enter the name to change");
					 sn=sc.next();
					 
					String upd="update student set sname=? where sid=?";
					pst=conn.prepareStatement(upd);
					pst.setString(1,sn);
					pst.setInt(2, stid);
					
					int rv=pst.executeUpdate();
					if(rv>0) {
						System.out.println("Name is changed succesfully");
					}else {
						System.out.println("Error!!");
					}
				
			 break;
			 
			 case 2:
				
					 System.out.println("Enter the fees you want to update");
					 float fees=sc.nextFloat();
					 String upd1="update student set sfees = ? where sid=?";
					 pst=conn.prepareStatement(upd1);
					 pst.setFloat(1, fees);
					 pst.setInt(2, stid);
					 
					 int rv1=pst.executeUpdate();
					 if(rv1>0) {
						 System.out.println("Fees has updated.");
						 
					 }else {
						 System.out.println("Error!");
						 
					 }
					 
				 
		 break;
		 default: System.out.println("Invalid input");
		 }//switch
			}//if(rs.next())
			else {
				
					 System.out.println("Id doesn't exists");
				
			}
		 }
	
	}


