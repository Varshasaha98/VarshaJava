package com.prog;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class MainPrepared {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/shonadatabase";
		String un="root";
		String up="root";
		Connection conn=null;
		PreparedStatement pst;
		ResultSet rs=null;
		int id,cid;
		String sn,dob;
		float fs;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the sid");
		id=sc.nextInt();
		System.out.println("Enter the Name");
		sn=sc.next();
		System.out.println("Enter the Date of birth");
		dob=sc.next();
		System.out.println("Enter the course you want to select:- 20,21,32");
		cid=sc.nextInt();
		System.out.println("Enter the fees ");
		fs=sc.nextFloat();
		
		try {
			
			Class.forName(driver); //load the driver at run time, register 
			conn = DriverManager.getConnection(url,un,up); //create the connection
			String s="insert into student values(?,?,?,?,?)";
			pst=conn.prepareStatement(s);
			
			pst.setInt(1, id);
			pst.setString(2, sn);
			pst.setInt(3, cid);
			pst.setString(4, dob);
			pst.setFloat(5, fs);
			
			int rv=pst.executeUpdate();
			if(rv>0) {
				System.out.println("Record is inserted");
			}
			else {
				System.out.println("Not inserted");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
