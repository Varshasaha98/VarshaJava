package com.edu.sms.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Subject {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer subjectId;
	private String subjectName;
	
	//relation
	
	@ManyToMany
	@JoinTable(name="student_enrolled", joinColumns =@JoinColumn( name= "subject_Id"),
	inverseJoinColumns = @JoinColumn(name="student_id"))
	Set<Student>enrolledstudent=new HashSet<>();
	
	
	/////////////////////////////////Inside subject class add teacher
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="teacher_Id",referencedColumnName = "teacherId")
	
	private Teacher teacher;
	
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	
	
	
	
	//////////////////////////////////
	
	
	public Set<Student> getEnrolledstudent() {
		return enrolledstudent;
	}
	public void setEnrolledstudent(Set<Student> enrolledstudent) {
		this.enrolledstudent = enrolledstudent;
	}
	public Integer getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public void enrolledstudent(Student student) {
		enrolledstudent.add(student);
		
	}
	//in the subject class
	public void assignTeacher(Teacher teacher2) {
		this.teacher=teacher2;
		
	}
 
	
}
