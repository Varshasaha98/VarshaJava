package com.edu.sms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.sms.entity.Student;
import com.edu.sms.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService studentService;
	
	@GetMapping("/getstudents")
	public List<Student> getAllStudents(){
		return studentService.getAllStudents();
		}
	
	@PostMapping("/addstudents")
	public Student addStudents(@RequestBody Student student ) {
		return studentService.addStudents(student);
	}
	
}
