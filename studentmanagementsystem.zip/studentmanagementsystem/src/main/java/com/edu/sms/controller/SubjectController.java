package com.edu.sms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.sms.entity.Subject;
import com.edu.sms.service.SubjectService;

@RestController
public class SubjectController {

	@Autowired
	private SubjectService subjectService;
	
	@GetMapping("/getsubjects")
	public List<Subject> getSubjects(){
		return subjectService.getSubjects();
	}
	
	@PostMapping("/addsubjects")
	public Subject addSubject(@RequestBody Subject subject) {
		return subjectService.addSubjects(subject);
	}
	
	@PutMapping("/subject/{subid}/student/{stuid}")
	public Subject enrolledStudentToSubject(@PathVariable("subid") Integer subid,@PathVariable("stuid") Integer stuid) {
		return subjectService.enrolledStudentToSubject(subid,stuid);
		
	}
	
	//assign subject to teacher
	
	@PutMapping("/subject/{subid}/teacher/{teachid}")
	public Subject assignSubjectToTeacher(@PathVariable ("subid") Integer subid, @PathVariable ("teachid") Integer teachid) {
		return subjectService.assignSubjectToTeacher(subid,teachid);
		
	}
	
	
}
