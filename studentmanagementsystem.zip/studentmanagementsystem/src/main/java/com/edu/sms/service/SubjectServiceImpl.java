package com.edu.sms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.sms.entity.Student;
import com.edu.sms.entity.Subject;
import com.edu.sms.entity.Teacher;
import com.edu.sms.repository.StudentRepository;
import com.edu.sms.repository.SubjectRepository;
import com.edu.sms.repository.TeacherRepository;

@Service
public class SubjectServiceImpl implements SubjectService{

	@Autowired
	private SubjectRepository subjectRepository;
	@Autowired
	private StudentRepository studentRepository;
	@Autowired
	private TeacherRepository teacherRepository;
	
	@Override
	public List<Subject> getSubjects() {
		
		return  subjectRepository.findAll();
	}

	@Override
	public Subject addSubjects(Subject subject) {
		
		return subjectRepository.save(subject);
	}

	@Override
	public Subject enrolledStudentToSubject(Integer subid, Integer stuid) {
		Subject subject =subjectRepository.findById(subid).get();
		Student student =studentRepository.findById(stuid).get();
		subject.enrolledstudent(student);
		return subjectRepository.save(subject);
	}

	@Override
	public Subject assignSubjectToTeacher(Integer subid, Integer teachid) {
		Subject subject = subjectRepository.findById(subid).get();
		Teacher teacher = teacherRepository.findById(teachid).get();
		subject.assignTeacher(teacher);
		return subjectRepository.save(subject);
	}

	
}
