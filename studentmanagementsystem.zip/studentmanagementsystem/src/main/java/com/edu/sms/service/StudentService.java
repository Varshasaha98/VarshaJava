package com.edu.sms.service;

import java.util.List;

import com.edu.sms.entity.Student;

public interface StudentService {

	List<Student> getAllStudents();

	Student addStudents(Student student);

}
