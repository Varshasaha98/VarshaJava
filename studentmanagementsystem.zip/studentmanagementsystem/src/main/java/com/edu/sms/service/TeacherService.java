package com.edu.sms.service;

import java.util.List;

import com.edu.sms.entity.Teacher;

public interface TeacherService {

	Teacher addTeacher(Teacher teacher);

	List<Teacher> getTeacher();

}
