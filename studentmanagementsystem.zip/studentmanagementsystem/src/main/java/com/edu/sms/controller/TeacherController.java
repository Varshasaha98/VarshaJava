package com.edu.sms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.sms.entity.Teacher;
import com.edu.sms.service.TeacherService;

@RestController
public class TeacherController {

	@Autowired
	private TeacherService teacherService;
	
	@PostMapping("/addteacher")
	public Teacher addTeacher(@RequestBody Teacher teacher){
		return teacherService.addTeacher(teacher);
		
	}
	@GetMapping
	public List<Teacher> getTeacher(){
		return teacherService.getTeacher();
		
	}
}
