package com.edu.sms.service;

import java.util.List;

import com.edu.sms.entity.Subject;

public interface SubjectService {

	List<Subject> getSubjects();

	Subject addSubjects(Subject subject);

	Subject enrolledStudentToSubject(Integer subid, Integer stuid);

	Subject assignSubjectToTeacher(Integer subid, Integer teachid);

}
