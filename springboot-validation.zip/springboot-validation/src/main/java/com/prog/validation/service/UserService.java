package com.prog.validation.service;

import javax.validation.Valid;

import com.prog.validation.entity.User;

public interface UserService {

	User userService(@Valid User user);

}
