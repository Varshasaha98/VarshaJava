package com.prog.validation.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;



@Entity
public class User {


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer userId;
	@NotEmpty(message = "Username should not be empty")
	@Size(min=3,max=30,message="Name should be min 3 chars and max=30")
	private String userName;
	@NotEmpty(message = "Password should not ne empty")
	@Size(min=4,max=30, message="password should be min 4 and max 30 chars")
	private String userPassword;
	@NotEmpty(message = "Usermail id should not be blank or not null")
	@Email(message="Invalid Email id")
	private String userEmail;
	private int age;
	
	
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

}
