package com.prog.validation.service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prog.validation.entity.User;
import com.prog.validation.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;

	@Override
	public User userService(@Valid User user) {
		
		return userRepository.save(user);
	}
	
	
}
