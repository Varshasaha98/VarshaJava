package com.prog;

public class MainAppString {

	public static void main(String[] args) {
		String s="hello world";
		int vc=0;
		int l = s.length();
		System.out.println("No. of chars= "+l);
		
		for(int i=0;i<l;i++) {
			char ch=s.charAt(i);
			if(ch=='A' || ch=='E' || ch=='I' || ch=='O' ||ch=='U' || ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u') {
				vc++;
			}
		}
		System.out.println("no. of vowels = "+vc);

	}

}
