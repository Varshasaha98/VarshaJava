package com.prog;

public class StringFunctionsMain {

	public static void main(String[] args) {
		String s="Hello";
		
		System.out.println("index of l"+s.indexOf('l'));
		System.out.println("last index of"+s.lastIndexOf('l'));
		
		
	}

}
