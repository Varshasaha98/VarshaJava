package com.prog;

import java.util.Scanner;
public class ValidateUserMain {

	public static void main(String[] args) {
		String un,pass;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter user name");
		un=sc.next();
		System.out.println("Enter password");
		pass=sc.next();
		if(un.equalsIgnoreCase("admin")&&pass.equals("admin123")) {
			System.out.println("user valid");
			
		}
		else {
			System.out.println("Not Valid");
		}

	}

}
