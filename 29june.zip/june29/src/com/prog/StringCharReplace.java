package com.prog;

import java.util.Scanner;

public class StringCharReplace {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string in upper case");
		String s=sc.nextLine();
		String newstr="";
		int len=s.length();
		
		for(int i=0;i<len;i++) {
			char ch=s.charAt(i);
			if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U') {
				newstr=newstr+"*";
			}
			else {
				newstr=newstr+ch;
			}
		}
		System.out.println(newstr);

	}

}
