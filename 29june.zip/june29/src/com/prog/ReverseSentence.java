package com.prog;

import java.util.Scanner;

public class ReverseSentence {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Sentence to reverse:");
		String s= sc.nextLine();
		s=" "+s;
		String s1="";
		
		for(int i=s.length()-1;i>=0;i--) {
			char ch=s.charAt(i);
			if(ch==' ') {
				System.out.print(s1+" ");
				s1="";
			}
			else {
				s1=ch+s1;
			}
		}

	}

}
