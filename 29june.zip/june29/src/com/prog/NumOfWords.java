package com.prog;

public class NumOfWords {

	public static void main(String[] args) {
		String s="Netaji Shubhash Chandra Bose";
		int ch1=0,l=s.length();
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i); 
			
			if(ch!=' ') {
				ch1++;
			}
		
	}
		System.out.println("no of characters excluding blank= "+ch1);

}
}
