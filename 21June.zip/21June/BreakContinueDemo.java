package com.progrm;

import java.util.Scanner;

public class BreakContinueDemo {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int i;
		i=1;
		while(true) {
			System.out.println(i);
			i=i+1;
			System.out.println("do you want to continue y/n");
			char ch = sc.next().charAt(0);
			if(ch=='n') {
				break;
			}
			else 
			{
				continue;
			}
			
		}
	}

}
