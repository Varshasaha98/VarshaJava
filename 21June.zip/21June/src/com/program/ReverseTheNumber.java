package com.program;

import java.util.Scanner;

class Reverse {
	int rev=0;
	int d;
	int num;
	void inputData() {
		int num;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number here:");
		num=sc.nextInt();
	
	}
	
	void calculateData() {
		
		while(num>0) {
			d=num%10;
			System.out.print(d);
			rev=rev*10+d;
			num=num/10;
		}
	}
	
	//void palindrome() {
		
		//if(rev==num) {
			//System.out.println("the number is palindrome");
		//}
		//else {
			//System.out.println("The number is not palindrome");
		//}
	//}
	void displayData() {
		System.out.println(rev);
		
	}
	
	
}

public class ReverseTheNumber {

	public static void main(String[] args) {
		
		Reverse obj = new Reverse();
		obj.inputData();
		obj.calculateData();
		//obj.palindrome();
		
	}

}
