package com.program;

import java.util.Scanner;
public class PrintName {
   public static void main(String[] args) {
	   int i;
	   String name;
	   Scanner sc = new Scanner(System.in);
	   System.out.println("Enter your name:");
	   name = sc.nextLine();
	  i=1;
	   while(i<=10) {
		   System.out.println("Name= "+name);
		   i++;
		   
	   }
   }
}
