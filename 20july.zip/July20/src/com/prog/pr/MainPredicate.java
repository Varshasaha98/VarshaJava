package com.prog.pr;

import java.util.function.Predicate;

public class MainPredicate {

	public static void main(String[] args) {
		System.out.println("Predicate Test");
		
		Predicate<Integer> pob = (i)->(i>10);
		boolean val = pob.test(15);
		System.out.println("return value = "+val);
		

	}

}
