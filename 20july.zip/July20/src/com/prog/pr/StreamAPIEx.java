package com.prog.pr;

import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Stream;

public class StreamAPIEx {

	public static void main(String[] args) {
		List<Integer> lst = new ArrayList<Integer>();
		
		for (int i=1;i<=100;i++) {
			lst.add(i);
			
		}
		System.out.println(lst);
		
		Stream<Integer> s = lst.stream(); //applied lambda
		
		//filter the elements greater than 75
		
		List<Integer> ls =s.filter(i->i>75).collect(Collectors.toList());
		System.out.println("List using Lambda"+ls);
		

	}

}
