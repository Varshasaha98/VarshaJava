package com.example.demo.error;

public class DepartmentNotFoundException extends Exception{
	
	public DepartmentNotFoundException (String message) {
	
		super(message);
	}

}
