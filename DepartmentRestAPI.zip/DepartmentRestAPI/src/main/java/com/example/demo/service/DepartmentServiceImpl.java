package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Department;
import com.example.demo.error.DepartmentNotFoundException;
import com.example.demo.repository.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentRepository departmentRepository;
	@Override
	public Department departmentSave(Department department) {
		
		return departmentRepository.save(department);
	}
	@Override
	public List<Department> getAllDepartment() {
		
		return departmentRepository.findAll();
	}
	@Override
	public Department findDepartmentById(Long deptid) throws DepartmentNotFoundException {
		
		//return departmentRepository.findById(deptid).get();
	
		Optional<Department> department = departmentRepository.findById(deptid);
		
		if(!department.isPresent())
			throw new DepartmentNotFoundException("Department Id not found");
		
		return department.get();
			
			
			
	}
	@Override
	public void deleteDepartmentById(Long deptid) throws DepartmentNotFoundException {
		//departmentRepository.deleteById(deptid);
		Optional<Department> department = departmentRepository.findById(deptid);
		
		if(!department.isPresent())
			throw new DepartmentNotFoundException("Department Id is not present");
		departmentRepository.deleteById(deptid);
	}
	
	@Override
	public Department updateDepartment(Long departmentId, Department department) throws DepartmentNotFoundException {
		//
		Optional<Department> department1 = departmentRepository.findById(departmentId);
		
		if(!department1.isPresent())
			throw new DepartmentNotFoundException("Department Id not available");
		
		else {
			Department deptDB = departmentRepository.findById(departmentId).get();
		if(department.getDepartmentAddress()!=null)
			deptDB.setDepartmentAddress(department.getDepartmentAddress());
		if(deptDB.getDepartmentName()!=null)
			deptDB.setDepartmentName(department.getDepartmentName());
		return departmentRepository.save(deptDB);
	}
	}
	@Override
	public Department fetchDepartmentName(String deptname) {
		
		return departmentRepository.findByDepartmentName(deptname);
	}
	
	
}
