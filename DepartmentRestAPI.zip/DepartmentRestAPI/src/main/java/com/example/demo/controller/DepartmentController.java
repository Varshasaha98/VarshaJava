package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Department;
import com.example.demo.error.DepartmentNotFoundException;
import com.example.demo.service.DepartmentService;

@RestController
public class DepartmentController {

	//Inject an object of DepartmentService using @Autowired automation
	@Autowired
	private DepartmentService departmentService;
	
	
	
	@PostMapping("/adddepartment") /* http://localhost:8889/adddepartment */
	public Department departmentSave( @Valid @RequestBody Department department) {
		return departmentService.departmentSave(department);
	
		
	}
	@GetMapping("/getalldepartment")
	public List<Department> getAllDepartment(){
	       return departmentService.getAllDepartment();
		
	}
	//find the record based on Id
	@GetMapping("/finddepartmentbyid/{deptid}")/* http://localhost:8889/findbydepartmentid/1 */
	public Department findDepartmentById(@PathVariable("deptid") Long deptid) throws DepartmentNotFoundException {
		return departmentService.findDepartmentById(deptid);
		
		
	}
	
	@DeleteMapping("/deletebyid/{deptid}")
	public String deleteDepartmentById(@PathVariable("deptid") Long deptid) throws DepartmentNotFoundException {
		 departmentService.deleteDepartmentById(deptid);
		return "record deleted successfully";
	}
	
	//updateRecord
		@PutMapping("/updatedepartment/{deptid}")
		public Department updateDepartment(@PathVariable ("deptid") Long departmentId,@RequestBody Department department) throws DepartmentNotFoundException {
			return departmentService.updateDepartment(departmentId,department);
		}
		
		@GetMapping("/fetchdepartmentname/{deptname}")
		public Department fetchDepartmentName(@PathVariable ("deptname") String deptname) {
			return departmentService.fetchDepartmentName(deptname);
			
		}
}
