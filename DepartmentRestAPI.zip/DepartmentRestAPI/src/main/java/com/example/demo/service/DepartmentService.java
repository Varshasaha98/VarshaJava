package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Department;
import com.example.demo.error.DepartmentNotFoundException;

public interface DepartmentService {

	Department departmentSave(Department department);

	

	List<Department> getAllDepartment();



	Department findDepartmentById(Long deptid) throws DepartmentNotFoundException;


	void deleteDepartmentById(Long deptid) throws DepartmentNotFoundException;



	Department updateDepartment(Long departmentId, Department department) throws DepartmentNotFoundException;



	Department fetchDepartmentName(String deptname);

	
	

}
