package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MainDatabase {

	public static void main(String[] args) throws SQLException {
		String driver = "com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/shonadatabase";
		String un="root";
		String up="root";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			st=conn.createStatement();
			System.out.println(conn);
			String sel="Select * from Student";
			
			rs = st.executeQuery(sel);
			
			System.out.println(rs);
			System.out.println("sid\tsname\tdob\tcourse\tfees");
			
			while(rs.next()) {
				int sn = rs.getInt(1);
				String sname = rs.getString(2);
				int cid = rs.getInt(3);
				String dob=rs.getString(4);
				float fs=rs.getFloat(5);
				
				System.out.println(sn+"\t"+sname+"\t"+dob+"\t"+cid+"\t"+fs);
				
			}
			
					
		}catch(Exception e) {
		e.printStackTrace();
		
	}finally {
		conn.close();
	}

}
}
