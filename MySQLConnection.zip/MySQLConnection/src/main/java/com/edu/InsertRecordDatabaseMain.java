package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class InsertRecordDatabaseMain {

	public static void main(String[] args) {
		String driver = "com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/shonadatabase";
		String un="root";
		String up="root";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		int sid,cid;
		String sn;
		float sfees;
		String dob;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter student name");
		sn=sc.next();
		System.out.println("Enter student Id");
		sid=sc.nextInt();
		System.out.println("Enter student dob");
		dob=sc.next();
		System.out.println("Enter the student course");
		cid=sc.nextInt();
		System.out.println("Enter the fees:");
		sfees=sc.nextFloat();
		
		
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			st=conn.createStatement();
			//System.out.println(conn);
			String sel="Select * from student where sid="+sid;
			rs=st.executeQuery(sel);
			if(rs.next()) {
				System.out.println(sid+"already exist");
			}else {
				
	
			
			String ins="insert into student values("+sid+",'"+sn+"','"+cid+"','"+dob+"',"+sfees+")";
			System.out.println(ins);
			int rval=st.executeUpdate(ins);
			if(rval>0) {
				System.out.println("Record is added");
			}else {
				System.out.println("Record not added");
			}
			

	}}catch(Exception e)
		{
		e.printStackTrace();
	}


}
		}

	
