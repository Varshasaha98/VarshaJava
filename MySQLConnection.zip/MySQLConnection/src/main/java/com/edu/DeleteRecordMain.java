package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteRecordMain {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/shonadatabase";
		String un= "root";
		String up="root";
		int stid;
		Connection conn=null;
		ResultSet rs=null;
		Statement st=null;
		
		Scanner sc = new Scanner(System.in);
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url, un, up);
			st=conn.createStatement();
			System.out.println("Enter sid to delete record");
			stid=sc.nextInt();
			String sel = "Select * from student where sid="+stid;
			rs=st.executeQuery(sel);
			if(rs.next()) {
				String del="delete from student where sid ="+stid;
				int retval=st.executeUpdate(del);
				if(retval>0) {
					System.out.println("Record is deleted");
				}else {
					System.out.println("Error! occured");
				}
				
			}else {
				System.out.println(stid+"id doesn't exist");
			}
			
		}catch(Exception e) {
		
			e.printStackTrace();
		}

	}

}
