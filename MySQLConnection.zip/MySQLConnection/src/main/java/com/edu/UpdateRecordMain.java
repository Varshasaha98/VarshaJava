package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class UpdateRecordMain {

	public static void main(String[] args) {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/shonadatabase";
		String un="root";
		String up="root";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		
		int stid;
		Scanner sc = new Scanner(System.in);
		
		try {
			
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			st=conn.createStatement();
			
			System.out.println("Enter the sid to update");
			stid=sc.nextInt();
			System.out.println("Enter the name");
			String sname=sc.next();
			
			String sel="Select * from student where sid = "+stid;
			rs=st.executeQuery(sel);
			
			if(rs.next()) {
				String upd="update student set sname ='"+sname+"' where sid ="+stid;
				int retval=st.executeUpdate(upd);
				if(retval>0) {
					System.out.println("Student name changed");
					
				}else {
					System.out.println("Error!!!");
				}
				
			}else {
				System.out.println(stid+"not exists for updating record");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}
