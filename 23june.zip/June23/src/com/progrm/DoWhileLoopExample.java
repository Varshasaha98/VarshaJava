package com.progrm;

public class DoWhileLoopExample {

	public static void main(String[] args) {
		
		int i=1;
		
		while(i>1) {
			System.out.println("while"+i);
		}
		
		do {
			System.out.println("do while" +i);
		}while(i>1);

	}

}
