package com.progrm;

import java.util.Scanner;

public class FactorialMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num,i;
		double fact=1;
		System.out.println("Enter the number to find factorial");
		num = sc.nextInt();
		i=num;
		while(i>=1) {
			fact = fact*i;
			i--;
		}
		System.out.println("factorial of "+num+" is "+fact);

	}

}
