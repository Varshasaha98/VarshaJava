package com.progrm;

public class NestedForLoopMain {

	public static void main(String[] args) {
		int r=4,c=4;
		for(int i=8;i>=r;i--) {

			for(int b=i;b<=r;b++) {
				
				System.out.print("");
				for(int j=1;j<=c;j++) {
					System.out.print(i);
					
				}
			}
			
			/**/
		
		System.out.println();
		}
		
		
	}

}
