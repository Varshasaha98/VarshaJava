package com.edu;

public class TestThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
