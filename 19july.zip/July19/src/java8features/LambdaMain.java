package java8features;

@FunctionalInterface
interface LambdaInterface{
	void myfunct();
	
}

/*class HelloClass implements LambdaInterface{

	@Override
	public void myfunct() {
		
			
		
	}
	
}*/
public class LambdaMain {

	public static void main(String[] args) {
		//HelloClass ob = new HelloClass();
		
		
		LambdaInterface ob= new LambdaInterface() {

			@Override
			public void myfunct() {
				System.out.println("Hello interface");
				
			}
			
		};
		ob.myfunct();
		
		//Lambda Expression : Functional Programming
		LambdaInterface ob1 = ()->{
			
			System.out.println("Interfce function");
			
		};
		ob1.myfunct();

		Runnable rob = ()->{
			System.out.println("run method is called");
		};
		Thread tob = new Thread(rob);
		tob.start();
	}

}
