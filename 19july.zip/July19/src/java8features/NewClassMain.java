package java8features;

@FunctionalInterface
interface MyNewInter{
	void display(int i,String s);
	//void method1(String s);
}
public class NewClassMain {

	public static void main(String[] args) {
		MyNewInter nob = (i,s)->{
		System.out.println("Age ="+i+" Name = "+s);
		System.out.println("hello");
		};nob.display(24, "Varsha");

	

}

}
