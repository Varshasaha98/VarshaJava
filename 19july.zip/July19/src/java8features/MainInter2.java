package java8features;

@FunctionalInterface
interface CallInter{
	String myCallMethod(String s);
}

public class MainInter2 {

	public static void main(String[] args) {
		// using lambda expression
		
		CallInter mob =(s)->{
			//System.out.println("Functional interface "+s);
			return "Hello "+s;
		};
		mob.myCallMethod("Hello");
		String sob = mob.myCallMethod("Varsha");
		System.out.println(sob);
	

}}
