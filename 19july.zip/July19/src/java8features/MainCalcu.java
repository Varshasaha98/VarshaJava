package java8features;

@FunctionalInterface
interface AddInt{
	int add(int i, int j);
}

@FunctionalInterface
interface SubInt{
	int sub(int i, int j);
}

@FunctionalInterface
interface ProdInt{
	int prod(int i, int j); 
	
}

public class MainCalcu {

	public static void main(String[] args) {
		/*AddInt aob = (i,j)->{
			int s=i+j;
			return s;
			
		};*/
		AddInt aob = (i,j) ->i+j;
		System.out.println("sum = "+aob.add(3, 6));

		SubInt sob =(i,j)->i-j;
		System.out.println("Subtraction = "+sob.sub(45, 12));
		
		ProdInt pob = (i,j)->i*j;
		System.out.println("Product = "+pob.prod(8, 2));
	}

}
