package com.prog;

class Singletone{
	public static Singletone sob;
	private Singletone() {
		System.out.println("Constructor of singletone class");
		}
	public static Singletone getSingletoneObject() {
		sob=new Singletone();
		return sob;
	}
	public void display() {
		System.out.println("Display");
	}
}

public class SingletoneClassMain {

	public static void main(String[] args) {
	Singletone ob = Singletone.getSingletoneObject();
	ob.display();
	

	}

}
