package com.prog.inter;

interface One{
	void m1();
	
}
interface Two{
	void m2();
	
}
interface Three extends One,Two{
	void m3();
	
}
class Hello{
	
}
class Hi{
	
}

class IntClass extends Hello implements Three{
	@Override
	public void m1() {
		
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		
	}
}

public class InterfaceExtendMain {

	public static void main(String[] args) {
		IntClass ob = new IntClass();
		ob.m1();
		ob.m2();
		ob.m3();

	}

}
