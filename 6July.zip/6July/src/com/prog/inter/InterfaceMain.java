package com.prog.inter;

interface MyInterface{
	int val=10;
	void interfaceMethod1(); 
	void interfaceMethod2();
	
}


//In java a class can implement any no of interfaces
//but a class extend only one class

class MyClass implements MyInterface{
	@Override
	public void interfaceMethod1() {
		System.out.println("interfaceMethod()1 ="+val);
	}

	@Override
	public void interfaceMethod2() {
		System.out.println("interfaceMetod()2");
		
	}
	
}



public class InterfaceMain {

	public static void main(String[] args) {
	MyClass ob = new MyClass();
	ob.interfaceMethod1();
	ob.interfaceMethod2();

	}

}
